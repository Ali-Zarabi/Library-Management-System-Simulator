import java.util.ArrayList;
import java.util.Scanner;
/*
For my project I decided to do a library management system in which you will be able to borrow and return books. 
Books will come as “physical” copies or “digital” Ebooks. Using physical books you will be able to read the novel 
itself or view its synopsis. EBooks will be a subclass of physical books. You will be able to do everything a book 
can do; however, you’ll also be able to take digital notes and change the text color. Finally, you will be able to 
choose two books from the catalogue and compare them.
 */
public class ProjectOneTester
{
    //Initialize all String variables
    String input;
    String book;
    String compareBook1;
    String compareBook2;
    String choice;
    String equal;

    //Initialize all Boolean variables
    Boolean menu = true;
    Boolean menu2 = true;
    Boolean menu3 = true;
    Boolean manageLoop = true;
    Boolean returnLoop = true;
    Boolean colorLoop = true;
    Boolean compareLoop = true;
    Boolean compareLoop1 = true;
    Boolean compareLoop2 = true;

    //Initialize the scanner to allow user input
    Scanner scanner = new Scanner(System.in);

    //Create a default instance of the book class with default parameters
    book newbook = new book();


    public void main(String[] args) 
    {
        //Initialize three arraylists, one containing the library's available catalogue,
        //one containing any borrowed books and one containing all the user's notes
        ArrayList<String> books = new ArrayList<String>();
        books.add("Harry Potter");
        books.add("Maze Runner");
        books.add("Game Of Thrones");
        books.add("The Lord Of The Rings");
        ArrayList<String> copy = new ArrayList<String>(books); 
        ArrayList<String> borrowed = new ArrayList<String>();
        ArrayList<String> notes = new ArrayList<String>();

        while (menu == true)
        {
            //Take an input from the user and act accordingly
            System.out.println(
                """
                    Welcome to the digital library management site! Please type in the number corresponding to what you would like to do:
                                     
                                      [1]. Borrow   |   [2]. Manage   |   [3]. Return   |   [4]. Compare   |   [5]. Exit
                                     """);

            input = scanner.nextLine();
            switch(input)
            {
                //Allow the user to borrow a book
                case "1":
                    if (borrowed.size() > 0)
                    {
                        System.out.println("Cannot borrow more than one book at a time!");
                        menu2 = false;
                    }
                    else
                    {
                        while (menu2 == true)
                        {   
                        //Print all books and take an input on which one to borrow
                        System.out.println("What book would you like to borrow?: ");
                        for (int i = 0; i<books.size(); i++)
                        {
                            System.out.println("[" + (i) + "]. " + books.get(i));
                            System.out.println("");
                        }
                        choice = scanner.nextLine();
                        if (choice.length() != 1)
                        {
                            System.out.println("Invalid input, please try again...");
                        }
                        else if (Character.isDigit(choice.charAt(0)) == false){
                            System.out.println("Invalid input, please try again...");
                        }
                        else if (Integer.parseInt(choice)<books.size())
                        {
                            book = books.get(Integer.parseInt(choice));
                            menu2 = false;
                        }
                    }
                    menu2 = true;
                    while (menu3 == true)
                    {
                        //Take an input for if the user wants a "physical" or "EBook"
                        //copy of their book and create an instance of the respective class
                        System.out.println("""
                            How would you like to check your book out?:
                                [1]. Physical Copy  |  [2]. EBook 
                            """);
                    String type = scanner.nextLine();
                    switch(type)
                    {
                        case "1":
                        newbook = new book(book);
                        menu3 = false;
                        break;
                        case "2":
                        newbook = new EBook(book);
                        menu3 = false;
                        break;
                        default:
                        System.out.println("Invalid input, please try again...");
                    }   
                    }
                    menu3 = true;
                    //Remove the book from the books arraylist and add it 
                    //to the borrowed arraylist
                    books.remove(books.get(Integer.parseInt(choice)));
                    borrowed.add(book);
                    System.out.println("Book successfully checked out !");
                }
                break;
                //Allow the user to manage their borrowed book
                case "2":
                while (manageLoop == true)
                {
                    //Take an input from the user and act accordingly
                    System.out.println("""
                          What would you like to do ?

[1]. Read Synopsis | [2]. Read Book | [3]. Take Notes | [4]. Read Notes | [5]. Text Color | [6]. Back
                            """);
                    String manage = scanner.nextLine();
                    switch (manage)
                    {
                        //Print the synopsis of the book
                        case "1":
                        System.out.println(newbook.toString());
                        System.out.println("Press [Enter] to continue...");
                        scanner.nextLine();
                        break;
                        //Print the book
                        case "2":
                        System.out.println(newbook.read());
                        scanner.nextLine();
                        break;
                        //Allow the user to take notes if their copy is an EBook
                        case "3":
                        String note = newbook.notes();
                        if (!(newbook instanceof EBook)) {System.out.println(note);}
                        else{notes.add(note);}
                        break;
                        //Print all the notes
                        case "4":
                        {
                            for (int i = 0; i<notes.size(); i++)
                            {
                                System.out.println((i+1) + ". " + notes.get(i));
                            }
                        }
                        break;
                        //If the users book is an EBook, take an input on whatever color 
                        //they want the text and apply that color accordingly
                        case "5":
                        while (colorLoop == true)
                        {
                            if (!(newbook instanceof EBook))
                            {
                            System.out.println("You do not have an EBook out right now...");
                            colorLoop = false;
                            }
                            else if (newbook instanceof EBook)
                            {
                                System.out.println("""
          What color would you like your text?: 

[1]. Red | [2]. Green | [3]. Yellow | [4]. Blue | [5]. Default
                                        """);
                                String color = scanner.nextLine();
                                newbook.color(color);
                                colorLoop = false;
                            }
                        }
                        colorLoop = true;
                        break;
                        //Return to the main menu screen
                        case "6":
                        manageLoop = false;
                        break;
                        default:
                        System.out.println("Invalid input, please try again...");
                    }
                }
                manageLoop = true;
                break;
                //Make sure the user wants to return the book and return it accordingly
                case "3":
                while (returnLoop == true)
                {
                    if (borrowed.size() > 0)
                    {
                        String ask = "Are you sure you would like to return your book, %s? [Y/N]";
                        ask = String.format(ask, newbook.getTitle());
                        System.out.println(ask);
                        String back = scanner.nextLine();
                        switch (back.toLowerCase())
                        {
                            //Clear the notes and borrowed arraylists. Return the book 
                            //to the books araylist.
                            case "y":
                            books.add(borrowed.get(0));
                            notes.clear();
                            borrowed.clear();
                            System.out.println("Book Returned");
                            newbook = new book();
                            returnLoop = false;
                            break;
                            case "n":
                            returnLoop = false;
                            break;
                            default:
                            System.out.println("Invalid input, please try again...");
                        }
                    }
                    else
                    {
                        System.out.println("you do not have any books out right now...");
                        returnLoop = false;
                    }
                }
                    returnLoop = true;
                    break;
                    //Ask which two books the user would like to compare and compare accordingly
                    case "4":
                    System.out.println("What two books would you like to compare?: ");
                    while (compareLoop == true)
                    {
                        //Ensure a valid input and get the first book
                        while (compareLoop1 == true)
                        {
                            System.out.println("Book one: ");
                            for (int i = 0; i<copy.size(); i++)
                            {
                                System.out.println("[" + (i) + "]. " + copy.get(i));
                                System.out.println("");
                            }
                            choice = scanner.nextLine();
                            if (choice.length() != 1)
                            {
                                System.out.println("Invalid input, please try again...");
                            }
                            else if (Character.isDigit(choice.charAt(0)) == false){
                                System.out.println("Invalid input, please try again...");
                            }
                            else if (Integer.parseInt(choice)<copy.size())
                            {
                                compareBook1 = copy.get(Integer.parseInt(choice));
                                compareLoop1 = false;
                                System.out.println("Book one successfully chosen");
                            }
                        }
                        compareLoop1 = true;
                        //Ensure a valid input and get the second book
                        while (compareLoop2 == true)
                        {
                            System.out.println("Book two: ");
                            for (int i = 0; i<copy.size(); i++)
                            {
                                System.out.println("[" + (i) + "]. " + copy.get(i));
                                System.out.println("");
                            }
                            choice = scanner.nextLine();
                            if (choice.length() != 1 )
                            {
                                System.out.println("Invalid input, please try again...");
                            }
                            else if (Character.isDigit(choice.charAt(0)) == false){
                                System.out.println("Invalid input, please try again...");
                            }
                            else if (Integer.parseInt(choice)<copy.size())
                            {
                                compareBook2 = copy.get(Integer.parseInt(choice));
                                compareLoop2 = false;
                            }
                        }
                        compareLoop2 = true;
                        //Create a class for the two books
                        book compare1 = new book(compareBook1);
                        book compare2 = new book(compareBook2);
                        //Print whether the books are equal or not
                        if (compare1.equals(compare2) == true)
                        {
                            equal = """
                                    %s compared to %s:

                                    These two books are the same!
                                    """;
                            equal = String.format(equal, compare1.getTitle(), compare2.getTitle());
                            System.out.println(equal);
                        }
                        else
                        {
                            equal = """
                                %s compared to %s:

                                These are two different books! 
                                """;
                            equal = String.format(equal, compare1.getTitle(), compare2.getTitle());
                            System.out.println(equal);
                        }
                        //Print the correct comparisons accordingly
                        int compareValue = compare1.compareTo(compare2);
                        if (compareValue == 1)
                        {
                            equal = """
                                %s is written by %s, whereas %s is written by %s.
                                %s is also higher rated at %f/5 stars, compared  
                                to %s at %f/5 stars.
                                """;
                            equal = String.format(equal, compare1.getTitle(), compare1.getAuthor(), compare2.getTitle(), compare2.getAuthor(), compare1.getTitle(), compare1.getRating(), compare2.getTitle(), compare2.getRating());
                            System.out.println(equal);
                        }
                        else if (compareValue == -1)
                        {
                            equal = """
                                %s is written by %s, whereas %s is written by %s.
                                %s is lower rated at %f/5 stars, compared to %s
                                at %f/5 stars.
                                """;
                            equal = String.format(equal, compare1.getTitle(), compare1.getAuthor(), compare2.getTitle(), compare2.getAuthor(), compare1.getTitle(), compare1.getRating(), compare2.getTitle(), compare2.getRating());
                            System.out.println(equal);
                        }
                            compareLoop = false;
                    }
                    compareLoop = true;
                    
                    break;
                    //Exit the program
                    case "5":
                    menu = false;
                    break;
                    default:
                    System.out.println("Invalid input, please try again...");
                    break;
            }
        }
        System.out.println("Thank you, goodbye!");
    }
}