import java.util.Scanner;


//Class containing all book methods
public class book implements Comparable<Object>{

    //Initialize all String variables
    private String author;
    private String title;
    private String synopsis;
    private double rating;
    private String narrator = "No Narrorator";
    private String novel = """

%s, written by %s:

         ,..........   ..........,
     ,..,'~~~~~~~~~ '.' ~~~~~~~~ ',..,
    ,' ,' ~~~~~~~~~~ : ~~~~~~~~~  ', ',
   ,' ,'  ~~~~~~~~~~ : ~~~~~~~~~   ', ',
  ,' ,'   ~~~~~~. 1  : ~~~~~~~~. 2  ', ',
 ,' ,'............., : ,.............', ',
,'  '............   '.'   ............'  ',
 '''''''''''''''''';''';''''''''''''''''''
                    '''

    Press [Enter] to close the book...
                """;

    //Initialize the scanner to allow for user input
    Scanner scanner = new Scanner(System.in);

    //Create a default constructor for the empty state of the class
    public book()
    {
        author = "N/A";
        title = "N/A";
        synopsis = "You don't have a book out right now";
    }
    
    //Overload the default constructor with one that initializes the books
    //based on user input 
    public book(String input)
    {
        //Set the correct variables based on the novel the user borrowed
        switch(input)
        {
            case "Harry Potter":
            this.title = "Harry Potter";
            this.author = "J.K Rowling";
            this.rating = 4.8;
            synopsis = """
                    Harry Potter - J.K Rowling:
                    The Harry Potter series follows a young wizard, Harry Potter, as he discovers his magical heritage and
                    battles the dark lord Voldemort. Alongside friends Hermione and Ron, he uncovers secrets, faces
                    dangers at Hogwarts, and ultimately confronts Voldemort in a final battle between good and evil.
                    """;
            break;
            case "Maze Runner":
            this.title = "Maze Runner";
            this.author = "James Dashner";
            this.rating = 4.6;
            synopsis = """
                    Maze Runner - James Dashner:
                    Thomas wakes up in a mysterious maze with no memory of his past. Alongside other trapped teens, he
                    must navigate deadly obstacles, uncover the maze's secrets, and escape before time runs out.
                    """;
            break;
            case "Game Of Thrones":
            this.title = "Game Of Thrones";
            this.author = "George R. R. Martin";
            this.rating = 4.7;
            synopsis = """
                    Game of Thrones - Georde R. R. Martin:
                    Noble families fight for control of the Iron Throne in the land of Westeros, while dark forces gather
                    beyond the Wall. Betrayal, war, and magic shape the fate of the realm in a brutal struggle for power.
                    """;
            break;
            case "The Lord Of The Rings":
            this.title = "The Lord Of The Rings";
            this.author = "J.R.R. Tolkien";
            this.rating = 4.8;
            synopsis = """
                    J.R.R. Tolkien:
                    Frodo Baggins, a humble hobbit, embarks on a quest to destroy the One Ring before the dark lord
                    Sauron can reclaim it. With the help of a fellowship, he faces great perils to save Middle-earth from evil.
                    """;
            break;
        }
    }

    //Create all the getters
    public String getAuthor() {return author;}
    public String getTitle() {return title;}
    public String getNarrator() {return narrator;}
    public double getRating() {return rating;}

    //Method to format the novel's text and return it
    public String read()
    {
        if (author == "N/A") {return "You have no book out right now. Press [Enter] to continue...";}
        else
        {
        novel = String.format(novel, title, author);
        return(novel);
        }
    }

    //Method to take notes (not applicable for the book class)
    public String notes()
    {
        return "You do not have an EBook out right now...";
    }

    //Method to change the text color (not applicable for the book class)
    public void color(String color)
    {
    }

    //Override the toString method to return the synopsis of the novel
    @Override
    public String toString()
    {
        return synopsis;
    }

    //Override the equals method to compare if two books are the same
    @Override
    public boolean equals(Object o)
    {
        if (this == o){return true;}
        else if (!(o instanceof book || o instanceof EBook)) {return false;}
        return this.getRating() == ((book) o).getRating();
    }

    //Override the compareTo method to compare the ratings of two books
    @Override
    public int compareTo(Object o) 
    {
        if (this == o) {return 0;}
        else if (!(o instanceof book || o instanceof EBook)) {return -2;}  
        book obj = (book) o;
        if (this.getRating() > obj.getRating()){return 1;}
        else if (this.getRating() < obj.getRating()){return -1;}
        else {return 0;}  
    }
}
