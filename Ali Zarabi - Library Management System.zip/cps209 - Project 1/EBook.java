//Subclass of book that contains all the EBook methods
public class EBook extends book{
    //Initialize all the String variables
    private String narrator;
    private String author;
    private String title;
    private String synopsis;

    //Initialize all the colors
    private String reset = "\u001B[0m";
    private String red = "\u001B[31m";
    private String green = "\u001B[32m";
    private String yellow = "\u001B[33m";
    private String blue = "\u001B[34m";
    private String white = "\u001B[37m";
    private String color;

    //Implement the default contructor
    public EBook()
    {
        super();
    }

    //Implement the overloaded constructor
    public EBook(String input)
    {
        super(input);
        switch(input)
        {
            case "Harry Potter":
            this.title = "Harry Potter";
            this.author = "J.K Rowling";
            this.narrator = "Jim Dale";
            synopsis = """
                    Harry Potter - J.K Rowling
                    The Harry Potter series follows a young wizard, Harry Potter, as he discovers his magical heritage and
                    battles the dark lord Voldemort. Alongside friends Hermione and Ron, he uncovers secrets, faces
                    dangers at Hogwarts, and ultimately confronts Voldemort in a final battle between good and evil.
                    """;
            break;
            case "Maze Runner":
            this.title = "Maze Runner";
            this.author = "James Dashner";
            this.narrator =  "Mark Deakins";
            synopsis = """
                    Maze Runner - James Dashner:
                    Thomas wakes up in a mysterious maze with no memory of his past. Alongside other trapped teens, he
                    must navigate deadly obstacles, uncover the maze’s secrets, and escape before time runs out.
                    """;
            break;
            case "Game Of Thrones":
            this.title = "Game Of Thrones";
            this.author = "George R. R. Martin";
            this.narrator = "Roy Dotrice";
            synopsis = """
                    Game of Thrones - Georde R. R. Martin:
                    Noble families fight for control of the Iron Throne in the land of Westeros, while dark forces gather
                    beyond the Wall. Betrayal, war, and magic shape the fate of the realm in a brutal struggle for power.
                    """;
            break;
            case "The Lord Of The Rings":
            this.title = "The Lord Of The Rings";
            this.author = "J.R.R. Tolkien";
            this.narrator = "Robert Inglis";
            synopsis = """
                    J.R.R. Tolkien:
                    Frodo Baggins, a humble hobbit, embarks on a quest to destroy the One Ring before the dark lord
                    Sauron can reclaim it. With the help of a fellowship, he faces great perils to save Middle-earth from evil.
                    """;
            break;
        }
    }

    //Override the notes method to allow user notes
    @Override
    public String notes()
    {
        System.out.println("Type what you would like to note: ");
        String note = scanner.nextLine();
        return note;
    }

    //Override the read method to allow the EBook to be read in a different format than the physical book
    @Override
    public String read()
    {
        if (author == "N/A") {return "You have no book out right now. Press [Enter] to continue...";}
        else
        {
String novel = """
%s. Written by %s and narrated by %s:

    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
aliquip ex ea commodo consequat...

Press [Enter] to close the book...
                    """;
            //Format the book and ensure the users color choice applies
            novel = String.format(novel, title, author, narrator);
            if (color!=null) {novel = color + novel + reset;}
            return(novel);
        }
    }
    //override the color method to allow for colorful text
    @Override
    public void color(String color)
    {
        //Set the color based on the user's input
        switch (color)
        {
            case "1":
            this.color = red;
            System.out.println("Color Changed Successfully!");
            break;
            case "2":
            this.color = green;
            System.out.println("Color Changed Successfully!");
            break;
            case "3":
            this.color = yellow;
            System.out.println("Color Changed Successfully!");
            break;
            case "4":
            this.color = blue;
            System.out.println("Color Changed Successfully!");
            break;
            case "5":
            this.color = white;
            System.out.println("Color Changed Successfully!");
            break;
            default:
            System.out.println("Invalid input, please try again...");
        }
    }
}
